/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jscuola;

/**
 *
 * @author Bellotti_mattia
 */
public class ThreadCerca extends Thread {
    private DatiCondivisi dc;
    private String nomeClasse;
    private int riga;

    public ThreadCerca() {
        dc=new DatiCondivisi();
        nomeClasse="";
        riga=0;
    }

    public ThreadCerca(DatiCondivisi dc, String nomeClasse, int riga) {
        this.dc = dc;
        this.nomeClasse = nomeClasse;
        this.riga = riga;
    }
    
    
    
    public void run(){
        
        
        dc.cercaClasse(nomeClasse,riga);
        dc.visualizza.Signal();
        dc.visualizza.Signal();
        dc.visualizza.Signal();
        dc.visualizza.Signal();
        dc.visualizza.Signal();
        dc.visualizza.Signal();
        dc.visualizza.Signal();
        
    }
    
    
}
