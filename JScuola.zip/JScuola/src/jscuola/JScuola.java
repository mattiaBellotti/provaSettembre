/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jscuola;

import java.util.Scanner;

/**
 *
 * @author Bellotti_mattia
 */
public class JScuola {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        DatiCondivisi dc=new DatiCondivisi();
        Scanner s = new Scanner(System.in);
        String classe= s.nextLine();
        dc.setClasse(classe);
        
        ThreadCerca c1=new ThreadCerca(dc,"5AI",2);
        ThreadCerca c2=new ThreadCerca(dc,"5AI",3);
        ThreadCerca c3=new ThreadCerca(dc,"5AI",4);
        ThreadCerca c4=new ThreadCerca(dc,"5AI",5);
        ThreadCerca c5=new ThreadCerca(dc,"5AI",6);
        ThreadCerca c6=new ThreadCerca(dc,"5AI",7);
        ThreadCerca c7=new ThreadCerca(dc,"5AI",8);
        ThreadVisualizza th1= new ThreadVisualizza();
        
        c1.start();
        c2.start();
        c3.start();
        c4.start();
        c5.start();
        c6.start();
        c7.start();
        th1.start();
        
        try{
            c1.join();
        c2.join();
        c3.join();
        c4.join();
        c5.join();
        c6.join();
        c7.join();
        th1.join();
        }catch(Exception ex){
        }
        
    }
    
}
