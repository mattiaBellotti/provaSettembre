/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jscuola;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Bellotti_mattia
 */
public class DatiCondivisi {
    
    private String riga1;
    private String riga2;
    private String riga3;
    private String riga4;
    private String[]ora1;
    private String[]ora2;
    private String[]ora3;
    private String[]ora4;
    private String[]ora5;
    private String[]ora6;
    private String[]ora7;
    private String[]ora8;
    private String riga5;
    private String riga6;
    private String riga7;
    private String riga8;
    private String classe;
    Integer[]cont = null;
    
    Semaforo visualizza;
    String professore;
    String[] ore = null;
    public DatiCondivisi() {
        
        
        
        riga1="ORA,1^,2^,3^,4^,5^,6^,1^,2^,3^,4^,5^,6^,1^,2^,3^,4^,5^,6^,1^,2^,3^,4^,5^,6^,1^,2^,3^,4^,5^,6^,1^,2^,3^,4^,5^,tot ore";
        ora1=riga1.split(",");
        riga2="AGOSTONI G.,2BI,2CI LFS,1AI LFS,.,.,.,2CI,1AI,1BI LFS,2AI,.,.,-,-,-,-,-,-,1BI,2BI LFS,1CI LFS,.,2AI,.,1CI,2CI,1AI,.,2AI LFS,.,1CI,1BI,2BI,.,.,18";
        ora2=riga2.split(",");
        riga3="ALI' M.,3AL,4BS,.,4AL,5AS,.,5AL,5BL,.,4BL,3AS,.,-,-,-,-,-,-,4BS,3BS,3AL,4BL,.,.,.,.,4AL,3BS,4AS,.,3AS,5BL,5AL,5AS,4AS,20";
        ora3=riga3.split(",");
        riga4="ALIPRANDI S.,4AM LI5,4AM LI5,4BE,.,3EE,.,.,.,5AM LSM,5AM LSM,3EE LSM,3EE LSM,-,-,-,-,-,-,.,.,.,4BE LSM,4BE LSM,4AM,4AM,5AM LSM,.,4BE,5BM LSM,.,.,.,5BM LSM,5BM LSM,3EE,18";
        ora4=riga4.split(",");
        riga5="ANDREACCHI S.,5AI LI6,1CI LI4,4BI LI7,5BI LI7,.,.,3BI LI7,3BI LI7,5BI LI7,4CI LI7,4CI LI7,.,5AI LI6,5AI LI6,.,4BI LI7,4BI LI7,.,.,5BI LI7,5BI LI7,.,.,.,.,.,1CI LI4,3BI LI7,4CI LI7,.,-,-,-,-,-,18";
           ora5=riga5.split(",");
        riga6="ASTA L.,-,-,-,-,-,-,.,.,.,4AM,2AM,2AM,3EE,3EE,.,4AM,2AM,.,2AM,4AM,4AM,.,.,.,3EE,3EE,2AM,4AM,.,.,4AM,3EE,3EE,.,2AM,18";
        ora6=riga6.split(",");
        riga7="BALLABIO M.L.,5D,2B,1D,.,5AI,.,.,.,2B,5AI,2C,5D,.,.,1D,5D,2C,.,,,,,,,.,5AI,1D,2C,2B,.,-,-,-,-,-,15";
           ora7=riga7.split(",");
        riga8="BARDI P.,.,.,1BM LI4,5AI LI6,1CM LI4,.,-,-,-,-,-,-,1AM LI4,.,1CM LI4,.,.,.,5AI LI6,5AI LI6,1BM LI4,.,1AM LI4,.,1AC LI2,1AC LI2,1BC LI2,1BC LI2,.,.,5AI LI6,5AI LI6,4AI LI6,4AI LI6,3AI LI6,18";
         ora8=riga8.split(",");
         
         visualizza= new Semaforo(0);
         
        
    }
    
    public void setClasse(String c){
        this.classe=c;
    }
    
    public String[] cercaClasse(String classe,int riga){
        
     if(riga==2){
         for(int i=0;i<riga2.length();i++){
             if(ora2[i].equals(classe))
                 cont[i]=i;
                         
         }
     }
     if(riga==3){
          for(int i=0;i<riga3.length();i++){
             if(ora3[i].equals(classe))
                 cont[i]=i;
                         
         }
     }
     if(riga==4){
          for(int i=0;i<riga4.length();i++){
             if(ora4[i].equals(classe))
                  cont[i]=i;
                         
         }
     }
     if(riga==5){
          for(int i=0;i<riga5.length();i++){
             if(ora5[i].equals(classe))
                 cont[i]=i;
                         
         }
     }
     if(riga==6){
          for(int i=0;i<riga6.length();i++){
             if(ora6[i].equals(classe))
                  cont[i]=i;
         }
     }
     if(riga==7){
          for(int i=0;i<riga7.length();i++){
             if(ora7[i].equals(classe))
                  cont[i]=i;
                         
         }
     }
     if(riga==8){
          for(int i=0;i<riga8.length();i++){
             if(ora8[i].equals(classe))
                  cont[i]=i;
                         
         }
     }
     
     
     ore[0]= ora1[cont[0]];
     ore[1]= ora1[cont[1]];
     
     return ore;
        
        
    }
    
   
   public void visualizzaOrario(int riga){
       if(riga==2){
           for(int i=0;i<ora2.length;i++){
               System.out.println(ora2[0] + "," + ore[i]);
           
       }
       }
       if(riga==3){
           for(int i=0;i<ora3.length;i++){
               System.out.println(ora3[0]);
           
       }
       }
       if(riga==4){
           for(int i=0;i<ora4.length;i++){
               System.out.println(ora4[0]);
           
       }
       }
       if(riga==5){
           for(int i=0;i<ora5.length;i++){
               System.out.println(ora5[0]);
           
       }
       }
       if(riga==6){
           for(int i=0;i<ora6.length;i++){
               System.out.println(ora6[0]);
           
       }
       }
       if(riga==7){
           for(int i=0;i<ora7.length;i++){
               System.out.println(ora7[0]);
           
       }
       }
       if(riga==8){
           for(int i=0;i<ora8.length;i++){
               System.out.println(ora8[0]);
           
       }
       }
       
   }
    
    
    
}
